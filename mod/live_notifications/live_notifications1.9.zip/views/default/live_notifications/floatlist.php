<div class="live_notifications">				  	
    <div id="live_notifications_loader"></div>
    <div id="live_notifications_result"></div>
    <div id="live_notifications_see_more">
    	<a href="<?php $site_url = elgg_get_site_url();echo $site_url ?>live_notifications/all">
    		<?php echo elgg_echo('live_notifications:see_all'); ?>
    	</a>
    </div>
 </div>
