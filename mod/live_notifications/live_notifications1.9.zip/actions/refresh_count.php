<?php 
gatekeeper();

echo count_unread_notifications(25);